<?php
for($i=0;$i<100000;$i++) {
    echo "f";
}